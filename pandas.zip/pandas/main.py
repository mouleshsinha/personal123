# main.py (Your main Python script)

import square

number_to_square = 5
result = square.square_number(number_to_square)
print(f"The square of {number_to_square} is: {result}")
