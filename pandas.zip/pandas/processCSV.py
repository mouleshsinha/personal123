import pandas as pd
import os

def add_file_name_column(csv_file_path):
    # Read the CSV file into a pandas DataFrame
    df = pd.read_csv(csv_file_path)

    # Extract the file name from the path
    file_name = os.path.basename(csv_file_path)

    # Add a new column 'File Name' with the file name for all rows
    df['File Name'] = file_name

    # Save the modified DataFrame back to the original CSV file (overwrite)
    df.to_csv(csv_file_path, index=False)

    print("New column 'File Name' added and saved to", csv_file_path)

if __name__ == "__main__":
    # Folder where the 'employee.csv' file resides
    folder_path = 'C:\pandas\path_to_csv'

    # File path of 'employee.csv'
    csv_file_path = os.path.join(folder_path, 'employee.csv')

    # Check if the file exists in the specified folder
    if not os.path.exists(csv_file_path):
        print("Error: 'employee.csv' not found in the specified folder.")
    else:
        # Add the 'File Name' column and update the 'employee.csv' file
        add_file_name_column(csv_file_path)

