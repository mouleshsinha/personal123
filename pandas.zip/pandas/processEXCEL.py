import os
import pandas as pd

def add_filename_to_excel_sheets(excel_file_path):
    if not os.path.isfile(excel_file_path):
        print(f"Error: The file '{excel_file_path}' does not exist.")
        return

    # Load all sheets of the Excel file into a dictionary of DataFrames
    xls = pd.read_excel(excel_file_path, sheet_name=None)

    # Loop through each sheet and add the filename as a new column
    for sheet_name, df in xls.items():
        df['File_Name'] = os.path.basename(excel_file_path)
        xls[sheet_name] = df

    # Save all sheets back to the Excel file
    with pd.ExcelWriter(excel_file_path) as writer:
        for sheet_name, df in xls.items():
            df.to_excel(writer, sheet_name=sheet_name, index=False)

    print(f"File names added successfully to all sheets in '{excel_file_path}'.")

if __name__ == "__main__":
    # Configure the path to the XLSX file
    file_path = "C:/pandas/path_to_XSLX/employee.xlsx"   # Replace this with the actual file path

    add_filename_to_excel_sheets(file_path)



