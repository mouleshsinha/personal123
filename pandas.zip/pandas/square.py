# square.py

def square_number(number):
    """Function to square a given number.

    Args:
        number (int or float): The number to be squared.

    Returns:
        int or float: The square of the input number.
    """
    return number ** 2